def sayhi(name):
    print(f"Hello, {name}!")

sayhi("Wisdom")